pipenv run python ../src/manage.py makemigrations
pipenv run python ../src/manage.py migrate
pipenv run python ../src/manage.py runrok