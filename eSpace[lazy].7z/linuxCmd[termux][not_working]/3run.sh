python main-setup.py --run 1
pause
